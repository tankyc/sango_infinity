#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Sango Infinity 配置表体检脚本。

用途：
  1. 严格校验 JSON 语法，并检测重复键（标准 json 模块会静默保留最后一个，这里会报出来）。
  2. 检测顶层键是否与 ScenarioCommonData 的 [JsonProperty] 成员同名（会被 PopulateObject 吞掉）。
  3. 统计以 `_` 开头的注释键。
  4. 找出「只有索引键和文本键、一个数值字段都没有」的记录 —— 在稀疏覆盖语义下，
     这类行会把 C# 内置表的数值全部覆盖成 0。
  5. 检测各数组表的索引键是否重复。
  6. 可选：与 C# 内置表逐行对账（--csharp-builtin），精确判定第 4 条是「原版全 0」还是「漏写」。

用法：
  python check_config_json.py <json路径>
  python check_config_json.py <json路径> --csharp-builtin <对应.cs> --index-key event

退出码：0 = 通过（可能有警告）；1 = 存在错误。
"""

import argparse
import json
import os
import re
import sys

# ScenarioCommonData 里带 [JsonProperty] 的成员名。Data/Common 下的顶层键撞上这些会被 PopulateObject 合并。
RESERVED_TOP_KEYS = {
    "TerrainTypes", "BuildingTypes", "Features", "Abilities",
    "TroopTypes", "ItemTypes", "TroopAnimations", "AttributeChangeTypes",
    "PersonAttributeTypes", "CityLevelTypes", "Flags", "Provinces",
    "Regions", "Titles", "Officials", "Nations",
    "Skills", "PersonLevels", "JobTypes", "Buffs",
    "Techniques", "Personalities", "Argumentations", "AbilityLevelTypes",
    "PersonLibrary",
}

# 自动识别索引键时的候选顺序
INDEX_KEY_CANDIDATES = ["id", "event", "key", "place", "name"]

NUMERIC_TYPES = (int, float)


def is_comment_key(key):
    return isinstance(key, str) and key.startswith("_")


class Problem(object):
    def __init__(self, level, where, message):
        self.level = level          # ERROR / WARN
        self.where = where
        self.message = message

    def __str__(self):
        return "  [%s] %s: %s" % (self.level, self.where, self.message)


def load_json_strict(path, problems):
    """解析 JSON，同时把重复键报出来（object_pairs_hook 能看到原始键值对）。"""
    duplicate_keys = []

    def hook(pairs):
        seen = {}
        for k, v in pairs:
            if k in seen:
                duplicate_keys.append(k)
            seen[k] = v
        return seen

    with open(path, "r", encoding="utf-8-sig") as f:
        text = f.read()

    try:
        data = json.loads(text, object_pairs_hook=hook)
    except ValueError as e:
        problems.append(Problem("ERROR", "JSON 语法", str(e)))
        return None

    for k in duplicate_keys:
        problems.append(Problem("ERROR", "重复键", "键 %r 在同一对象里出现多次，只有最后一个生效" % k))
    return data


def check_top_keys(data, problems):
    """顶层键体检：保留名冲突 + 注释键统计 + 数组表定位。"""
    if not isinstance(data, dict):
        problems.append(Problem("ERROR", "结构", "顶层不是对象，无法按表结构处理"))
        return {}

    top_keys = list(data.keys())
    comment_keys = [k for k in top_keys if is_comment_key(k)]
    others = [k for k in top_keys if k not in comment_keys]

    # 顶层键命中 ScenarioCommonData 保留名：
    #   · 该键是文件里唯一的业务键 —— 这是「链路 A 的正常表」（Features.json 就是这种），安全；
    #   · 与其它业务键并存 —— 多半是新表误撞了保留名，内容会被 PopulateObject 吞进全局数据库。
    reserved_hits = [k for k in others if k in RESERVED_TOP_KEYS]
    for k in reserved_hits:
        if len(others) > 1:
            problems.append(Problem(
                "ERROR", "顶层键", "%r 与 ScenarioCommonData 的 [JsonProperty] 成员同名，"
                "且该文件还有其它业务键（%s）。PopulateObject 会把它合并进全局数据库，"
                "几乎可以确定是误撞，请改名" % (k, ", ".join(x for x in others if x != k))))
        else:
            problems.append(Problem(
                "NOTE", "顶层键", "%r 命中 ScenarioCommonData 保留名，按链路 A"
                "（全目录 PopulateObject）消费，属正常结构" % k))

    print("顶层键: %d 个（其中注释键 %d 个: %s）"
          % (len(top_keys), len(comment_keys), ", ".join(comment_keys) if comment_keys else "无"))
    print("业务键: %s" % (", ".join(others) if others else "无"))

    # 找出所有「记录表」，两种序列化形式都收：
    #   · 数组形式：[{...}, {...}]（CombatExpTable 的 entries）
    #   · 字典形式：{"1": {...}, "2": {...}}（SangoObjectSet / SangoObjectMap 的结果，如 Features.json）
    # 返回值：{表名: (记录列表, 字典键列表或 None)}
    tables = {}
    for k in others:
        v = data[k]
        if isinstance(v, list):
            if all(isinstance(x, dict) for x in v):
                tables[k] = (v, None)
        elif isinstance(v, dict):
            keys = [kk for kk in v.keys() if not is_comment_key(kk)]
            if keys and all(isinstance(v[kk], dict) for kk in keys):
                tables[k] = ([v[kk] for kk in keys], keys)
    return tables


def detect_index_key(rows, explicit):
    """确定记录表的索引键（大小写不敏感，优先取记录里实际出现的写法）。

    显式给了就用。否则按 INDEX_KEY_CANDIDATES 的顺序取第一个「所有记录都有」的键。
    这里**故意不要求值唯一** —— 唯一性正是下面要检查的目标，拿唯一性去筛候选键会
    把「索引重复」的表误判成「以 name 为键」，从而漏掉真问题。
    """
    if not rows or not all(isinstance(r, dict) for r in rows):
        return None

    def find(cand):
        for k in rows[0].keys():
            if k.lower() == cand.lower() and all(k in r for r in rows):
                return k
        return None

    if explicit:
        return find(explicit)

    for cand in INDEX_KEY_CANDIDATES:
        hit = find(cand)
        if hit:
            return hit
    return None


def to_int(value):
    """把字典表的字符串键转成整数，转不了返回原值。"""
    try:
        return int(value)
    except (TypeError, ValueError):
        return value


def check_array_table(name, rows, record_keys, explicit_index, problems, notes):
    """记录表体检：索引键重复、无数字段的记录。

    record_keys 非 None 表示该表是字典形式（{"1": {...}}），键本身即索引。
    返回「不含任何数值字段」的记录 [(标签, 索引值)]，由调用方决定报 WARN 还是降级为 NOTE ——
    提供 --csharp-builtin 时这些行会被对账精确验证，无需再告警。
    """
    if not rows:
        notes.append("%s: 空表" % name)
        return []
    if not all(isinstance(r, dict) for r in rows):
        notes.append("%s: 含非对象元素，跳过逐行体检" % name)
        return []

    index_key = detect_index_key(rows, explicit_index)
    if record_keys is not None:
        notes.append("%s: 字典形式（%d 条，对象键即索引），索引唯一性由 JSON 重复键检查覆盖"
                     % (name, len(rows)))
    elif index_key:
        seen = {}
        for i, r in enumerate(rows):
            v = r[index_key]
            if v in seen:
                problems.append(Problem(
                    "ERROR", name, "索引键 %s=%r 重复（第 %d 行与第 %d 行）"
                    % (index_key, v, seen[v] + 1, i + 1)))
            else:
                seen[v] = i
    else:
        notes.append("%s: 未识别出索引键（无共有的候选键），跳过重复检测" % name)

    # 字段使用频次
    freq = {}
    for r in rows:
        for k in r.keys():
            if not is_comment_key(k):
                freq[k] = freq.get(k, 0) + 1
    print("\n表 %r: %d 条记录，字段使用情况：" % (name, len(rows)))
    for k in sorted(freq, key=lambda x: (-freq[x], x)):
        print("    %-20s %d/%d" % (k, freq[k], len(rows)))

    # 一个数值字段都没有的记录 —— 稀疏覆盖下会把内置值清零
    empty_numeric = []
    for i, r in enumerate(rows):
        has_numeric = any(isinstance(v, NUMERIC_TYPES) and not isinstance(v, bool)
                          for k, v in r.items()
                          if not is_comment_key(k) and k != index_key)
        if not has_numeric:
            if record_keys is not None:
                label = record_keys[i]
                index_value = to_int(record_keys[i])
            else:
                label = r.get(index_key, "#%d" % (i + 1)) if index_key else (i + 1)
                index_value = r.get(index_key) if index_key else None
            empty_numeric.append((label, index_value))

    return empty_numeric


BUILTIN_RE = re.compile(
    r"\w+\s*\[\s*(0x[0-9a-fA-F]+|\d+)\s*\]\s*=\s*new\s+(\w+)\s*"
    r"(?:\{([^}]*)\}|\(\s*\))",
    re.S)
BUILTIN_FIELD_RE = re.compile(r"(\w+)\s*=\s*(-?\d+)")


def parse_csharp_builtin(cs_path, problems):
    """解析 `变量[索引] = new 类型 { 字段 = 值, ... };` 形式的内置表。"""
    if not os.path.isfile(cs_path):
        problems.append(Problem("ERROR", "C# 内置表", "文件不存在: %s" % cs_path))
        return None

    with open(cs_path, "r", encoding="utf-8-sig") as f:
        src = f.read()

    table = {}
    for m in BUILTIN_RE.finditer(src):
        raw_index = m.group(1)
        index = int(raw_index, 16) if raw_index.lower().startswith("0x") else int(raw_index)
        inner = m.group(3) or ""
        row = {}
        for fm in BUILTIN_FIELD_RE.finditer(inner):
            row[fm.group(1)] = int(fm.group(2))
        if index in table:
            problems.append(Problem("ERROR", "C# 内置表", "索引 %d 重复赋值" % index))
        table[index] = row

    if not table:
        problems.append(Problem(
            "WARN", "C# 内置表",
            "未解析到任何 `x[N] = new T { ... }` 形式的内置表，请人工比对"))
        return None
    return table


def check_against_builtin(rows, builtin, index_key, problems):
    """JSON 每行 vs C# 内置行逐字段对账。"""
    if not index_key:
        problems.append(Problem("ERROR", "对账", "无法确定索引键，不能与内置表对账"))
        return

    all_fields = set()
    for row in builtin.values():
        all_fields.update(row.keys())
    text_keys = set()

    json_indexes = set()
    for i, r in enumerate(rows):
        raw = r.get(index_key)
        if raw is None:
            problems.append(Problem("ERROR", "对账", "第 %d 行缺少索引键 %s" % (i + 1, index_key)))
            continue
        try:
            index = int(raw)
        except (TypeError, ValueError):
            problems.append(Problem("ERROR", "对账", "第 %d 行索引值 %r 不是整数" % (i + 1, raw)))
            continue
        json_indexes.add(index)

        if index not in builtin:
            problems.append(Problem(
                "ERROR", "对账", "索引 %s=%d 在内置表中不存在" % (index_key, index)))
            continue

        # 未知字段：会被 ToObject 静默忽略，多半是拼写错误
        for k in r.keys():
            if k == index_key or is_comment_key(k):
                continue
            if k not in all_fields:
                if isinstance(r[k], str):
                    text_keys.add(k)
                else:
                    problems.append(Problem(
                        "ERROR", "对账", "索引 %d 的字段 %r 不在 C# 内置表字段里（拼写错误？会被静默忽略）"
                        % (index, k)))

        # 数值对账：JSON 缺字段 = 0
        builtin_row = builtin[index]
        for field in sorted(all_fields):
            a = r.get(field, 0)
            if isinstance(a, bool) or not isinstance(a, NUMERIC_TYPES):
                a = 0
            b = builtin_row.get(field, 0)
            if int(a) != int(b):
                problems.append(Problem(
                    "ERROR", "对账",
                    "索引 %d 字段 %s: JSON=%s 内置=%s" % (index, field, a, b)))

    missing = sorted(set(builtin.keys()) - json_indexes)
    if missing:
        shown = missing if len(missing) <= 10 else missing[:10] + ["..."]
        problems.append(Problem(
            "WARN", "对账",
            "JSON 未覆盖的内置行共 %d 条: %s（会沿用内置值，通常无害，但请确认是有意的）"
            % (len(missing), shown)))

    print("\n对账：JSON %d 行 / C# 内置 %d 行，数值字段 %s"
          % (len(rows), len(builtin), sorted(all_fields)))
    if text_keys:
        print("    纯文本字段（不参与对账）: %s" % sorted(text_keys))


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="Sango 配置表体检")
    parser.add_argument("json", help="待检查的 JSON 文件")
    parser.add_argument("--csharp-builtin", dest="csharp", default=None,
                        help="与 JSON 对应的 C# 内置表源文件（链路 B 必填）")
    parser.add_argument("--index-key", dest="index_key", default=None,
                        help="数组表的索引键名，例如 event / id；不填则自动识别")
    parser.add_argument("--table", dest="table", default=None,
                        help="只检查指定的数组表（顶层键名）")
    args = parser.parse_args()

    problems = []
    notes = []

    print("== 检查 %s ==" % args.json)
    data = load_json_strict(args.json, problems)
    if data is None:
        for p in problems:
            print(p)
        return 1

    tables = check_top_keys(data, problems)
    if args.table:
        if args.table not in tables:
            problems.append(Problem("ERROR", "表", "找不到记录表 %r" % args.table))
        tables = {k: v for k, v in tables.items() if k == args.table}

    if not tables:
        notes.append("未发现记录表（既没有 [{...}] 形式的数组，也没有 {\"1\":{...}} 形式的字典），"
                     "只做了语法与顶层键检查")

    empty_numeric_rows = {}
    for name, (rows, record_keys) in tables.items():
        empty_numeric_rows[name] = check_array_table(
            name, rows, record_keys, args.index_key, problems, notes)

    builtin = None
    target_name = None
    if args.csharp:
        builtin = parse_csharp_builtin(args.csharp, problems)
        if builtin is not None and tables:
            if len(tables) == 1:
                target_name = list(tables.keys())[0]
            else:
                # 多张记录表时取记录最多的那张对账（空表 / 注释表不会被选中）
                target_name = max(tables.keys(), key=lambda k: len(tables[k][0]))
                notes.append("存在多张记录表，已自动选择记录最多的 %r 参与对账；"
                             "如需指定请加 --table" % target_name)
            rows = tables[target_name][0]
            index_key = detect_index_key(rows, args.index_key)
            check_against_builtin(rows, builtin, index_key, problems)

    # 不含数值字段的记录：逐行用内置表判定「原版全 0」还是「漏写」
    for name, items in empty_numeric_rows.items():
        if not items:
            continue
        confirmed = []
        pending = []
        for label, index_value in items:
            row = None
            if builtin is not None and name == target_name and isinstance(index_value, int):
                row = builtin.get(index_value)
            if row is not None and all(v == 0 for v in row.values()):
                confirmed.append(label)
            else:
                pending.append(label)

        if confirmed:
            notes.append("%s: %d 条记录不含任何数值字段（%s），已由 C# 内置表确认同为全 0，"
                         "属原版有意为之" % (name, len(confirmed), confirmed))
        if pending:
            problems.append(Problem(
                "WARN", name,
                "%d 条记录不含任何数值字段（%s）。稀疏覆盖语义下这些行的数值会全部变成 0，"
                "请确认是「原版全 0 行」而不是漏写" % (len(pending), pending)))

    errors = [p for p in problems if p.level == "ERROR"]
    warns = [p for p in problems if p.level == "WARN"]
    infos = [p for p in problems if p.level == "NOTE"]

    print("\n== 结果 ==")
    for p in errors + warns:
        print(p)
    for p in infos:
        print("  [NOTE] %s: %s" % (p.where, p.message))
    for n in notes:
        print("  [NOTE] %s" % n)

    print("\nERROR %d 项，WARN %d 项" % (len(errors), len(warns)))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
